<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;

class ManageApplications extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-identification';
    protected static ?string $navigationGroup = 'Recruitment';
    protected static ?int $navigationSort = 2;

    protected static string $view = 'filament.pages.manage-applications';

    public $applications = [];
    public $filters = [];
    public $links = [];

    public function mount(Request $request)
    {
        $this->filters = [
            'f_name' => $request->query('f_name'),
            'f_email' => $request->query('f_email'),
            'f_phone' => $request->query('f_phone'),
            'page' => $request->query('page', 1),
        ];

        $this->fetchData();
    }

    public function fetchData()
    {
        $response = Http::timeout(60)->get('https://cv.mintoku.vn/admin/applications', [
            'name' => $this->filters['f_name'],
            'email' => $this->filters['f_email'],
            'phone' => $this->filters['f_phone'],
            'page' => $this->filters['page'],
        ]);

        if ($response->successful()) {
            $payload = $response->object();
            $this->applications = $payload->data ?? [];
            $this->links = $payload->links ?? []; // Để làm phân trang nếu cần
        }
    }
}
